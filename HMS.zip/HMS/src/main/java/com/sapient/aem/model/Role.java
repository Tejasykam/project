package com.sapient.aem.model;

public enum Role {
	DOCTOR,PATIENT,ADMIN

}
