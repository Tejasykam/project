package com.sapient.aem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.sapient.aem.model.PatientHistory;

public class PatientHistoryDaoImpl implements PatientHistoryDAO {
	@Override
	public PatientHistory getPatientHistoryById(Integer patient_history_id) throws SQLException {
		String sql= "select * from  patient_history  where patient_history_id=?";
		Connection connection=null;
		try{
			Context envContext = (Context) new InitialContext().lookup("java:comp/env");		
			DataSource dataSource = (DataSource) envContext.lookup("jdbc/hmsDB");
			connection= dataSource.getConnection();
			PreparedStatement preparedStatement= connection.prepareStatement(sql);
			preparedStatement.setInt(1,patient_history_id);
			ResultSet resultSet= preparedStatement.executeQuery();
			if(resultSet.next()) {
				PatientHistory patientHistory= new PatientHistory();

				populatePatientHistory(resultSet,patientHistory);
				return patientHistory;				
			}else {
				return null;
			}

		}catch(SQLException e) {
			//			e.printStackTrace();
			throw e;
		}catch(Exception e) {
			throw new SQLException(e.getMessage());
		}finally {
			connection.close();
		}
	}

	@Override
	public   List<PatientHistory> getPatientHistory() throws SQLException {
		String sql="select * from patient_history where patient_history_id= ?";
		Connection connection=null;
		try {
			Context envContext = (Context) new InitialContext().lookup("java:comp/env");		
			DataSource dataSource = (DataSource) envContext.lookup("jdbc/hmsDB");
			connection= dataSource.getConnection();
			Statement statement= 
					connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
							ResultSet.CONCUR_UPDATABLE);
			ResultSet resultSet= statement.executeQuery(sql);
			int rowcount=0;
			if ( resultSet.last()) {
				rowcount =  resultSet.getRow();
				resultSet.beforeFirst(); // not  resultSet.first() because the  resultSet.next() below will move on, missing the first element
			}
			List<PatientHistory> patienthistoryList=new ArrayList<>();			
			while(resultSet.next()) {
				PatientHistory patienthistory= new PatientHistory();
				populatePatientHistory(resultSet,patienthistory);
				return (List<PatientHistory>) patienthistory ;				
			}
			return getPatientHistory();
		}catch(SQLException e) {
			throw e;
		}catch(Exception e) {
			throw new SQLException(e.getMessage());
		}finally {
			connection.close();
		}
	}
	private void populatePatientHistory(ResultSet resultSet, PatientHistory patienthistory) throws SQLException {
		patienthistory.setPatientHistoryId(resultSet.getInt("patienthistoryid"));
		patienthistory.setPatientName(resultSet.getString("patientName"));
		patienthistory.setCaseSheetOpenDate(resultSet.getDate("caseSheetOpenDate").toLocalDate());
		patienthistory.setCaseSheetCloseDate(resultSet.getDate("caseSheetCloseDate").toLocalDate());		
		patienthistory.setHostipalDetails(resultSet.getString("hospitalDetails"));
		patienthistory.setHealthStatistics(resultSet.getString("healthStatistics"));
		patienthistory.setSymptoms(resultSet.getString("symptoms"));
		patienthistory.setPrescription(resultSet.getString("prescrption"));
		patienthistory.setDiet(resultSet.getString("diet"));
		patienthistory.setPatientId(resultSet.getInt("patientId"));
	}
	
	@Override
	public String addPatientHistory(PatientHistory patienthistory) throws SQLException {
		String sql="insert into patient_history (patient_name,case_sheet_open_date ,case_sheet_close_date,hostipal_details,health_statistics,symptoms,prescription ,diet ,patient_id) values (?,?,?,?,?,?,?,?,?)";
		Connection connection=null;
		try{
			Context envContext = (Context) new InitialContext().lookup("java:comp/env");		
			DataSource dataSource = (DataSource) envContext.lookup("jdbc/hmsDB");
			connection= dataSource.getConnection();
			PreparedStatement preparedStatement= connection.prepareStatement(sql);
			preparedStatement.setString(1, patienthistory.getPatientName());
			preparedStatement.setDate(2,java.sql.Date.valueOf(patienthistory.getCaseSheetOpenDate()));
			preparedStatement.setDate(3,java.sql.Date.valueOf(patienthistory.getCaseSheetCloseDate()));
			preparedStatement.setString(4,patienthistory.getHostipalDetails());
			preparedStatement.setString(5,patienthistory.getHealthStatistics());
			preparedStatement.setString(6, patienthistory.getSymptoms());
			preparedStatement.setString(7,patienthistory.getPrescription());
			preparedStatement.setString(8,patienthistory.getDiet());
			preparedStatement.setInt(9, patienthistory.getPatientId());
			int n= preparedStatement.executeUpdate();
			if(n>0) {
				return "Added PatientHistory to database";
			}else {
				return "Unable to add PatientHistory to database";
			}

		}catch(SQLException e) {
			throw e;
		}catch(Exception e) {
			throw new SQLException(e.getMessage());
		}finally {
			connection.close();
		}
	}

	@Override
	public String updatePatientHistory(PatientHistory patienthistory) throws SQLException {
		String sql="update patient_history set hostipal_details=?, health_statistics=?, symptoms=?, prescription=?, diet=?  where patient_history_id=?";
		Connection connection=null;
		try {
			Context envContext = (Context) new InitialContext().lookup("java:comp/env");		
			DataSource dataSource = (DataSource) envContext.lookup("jdbc/hmsDB");
			connection= dataSource.getConnection();
			PreparedStatement preparedStatement= connection.prepareStatement(sql);
		
			preparedStatement.setString(1, patienthistory.getHostipalDetails());
			preparedStatement.setString(2, patienthistory.getHealthStatistics());
			preparedStatement.setString(3, patienthistory.getSymptoms());
			preparedStatement.setString(4,patienthistory.getPrescription());
			preparedStatement.setString(5,patienthistory.getDiet());
			int n = preparedStatement.executeUpdate();
			if(n>0) {
				return "Empno: "+ patienthistory.getPatientHistoryId()+" updated";
			}else {
				return "Unable to update empno: "+ patienthistory.getPatientHistoryId();
			}

		}catch(SQLException e) {
			throw e;
		}catch(Exception e) {
			throw new SQLException(e.getMessage());
		}finally {
			connection.close();
		}
	}
	@Override
	public String deletePatientHistory(Integer phid) throws SQLException {
		String sql="delete from patient_history where patientHistoryId=?";
		Connection connection=null;
		try{
			Context envContext = (Context) new InitialContext().lookup("java:comp/env");		
			DataSource dataSource = (DataSource) envContext.lookup("jdbc/hmsDB");
			connection= dataSource.getConnection();
			PreparedStatement preparedStatement= connection.prepareStatement(sql);
			int patientHistoryId = 1;
			preparedStatement.setInt(1, patientHistoryId);
			int n= preparedStatement.executeUpdate();
			if(n>0) {
				return "PatientHistory:"+patientHistoryId+" deleted from database";
			}else {
				return "Unable to delete PatientHistory: "+patientHistoryId;
			}
		}catch(SQLException e) {
			throw e;
		}catch(Exception e) {
			throw new SQLException(e.getMessage());
		}finally {
			connection.close();
		}
	}
	
	
}
